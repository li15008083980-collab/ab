# 货通达双端升级 3.2.7

本包包含：
- `desktop-extension/`：电脑端 Chrome/Edge Manifest V3 扩展。
- `mobile-app/`：**已补全可编译的 Android 原生工程**，包含 WebView 工作台、七个平台入口、本机客户库和系统级可拖动悬浮球服务。

## 手机端快速构建 APK（推荐）

### 方法一：使用 Android Studio（最简单）
1. 安装 [Android Studio](https://developer.android.com/studio)（最新稳定版）。
2. 打开 Android Studio → **Open** → 选择本包中的 `mobile-app` 文件夹。
3. 等待 Gradle Sync 完成（首次会自动下载依赖和 SDK）。
4. 菜单栏 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
5. 构建完成后点击提示中的 **locate**，得到 `app-debug.apk`。
6. 把 APK 传到手机安装即可。

### 方法二：使用 GitHub Actions 云端编译（无需本机环境）
1. 把整个 `huotongda-upgrade` 文件夹上传到你的 GitHub 仓库。
2. 打开仓库的 **Actions** 页面。
3. 选择 **Build HuoTongDa Android APK** 工作流，点击 **Run workflow**。
4. 构建成功后，在 Artifacts 下载 `huotongda-3.2.7-debug-apk`，解压得到 `app-debug.apk`。

### 安装与开启悬浮球
1. 安装 APK 后打开「货通达」。
2. 点击顶部「开启悬浮球」。
3. 在系统设置中允许「显示在其他应用上层」（悬浮窗权限）。
4. 返回 App 再次点击「开启悬浮球」。
5. Android 13+ 如提示通知权限，请允许（用于前台服务通知）。

悬浮球可拖动。点击后展开客户检索面板：关键词实时检索、分类筛选（工厂/外贸采购/出货需求/未分类）、跟进状态筛选与修改，并可在悬浮窗内直接添加客户，不必先回工作台。拨打、复制、WhatsApp 快捷操作与电脑端客户库逻辑对齐。

## 功能说明与限制
- 客户资料保存在 App 本机，并同步给悬浮窗检索。支持 JSON 备份/恢复。
- 电脑扩展与手机端数据暂未云端同步。
- 悬浮球只检索本机客户库，**不会读取其他 App 内容**，也不绕过平台登录与隐私限制。
- 平台 App Scheme 是否可用取决于手机是否安装对应官方 App；否则回退到网页。

## 版本
- 当前版本：**3.2.7**
- 构建产物为 debug APK，首次安装需允许「安装未知应用」。
