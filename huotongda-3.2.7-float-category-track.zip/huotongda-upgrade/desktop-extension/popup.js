const STORAGE_KEY = 'fb_leads';
const STATUS_OPTIONS = ['待联系', '已联系', '已回复', '已报价', '成交', '无效'];
const CATEGORY_OPTIONS = ['工厂', '采购商', '出货需求', '未分类'];
let currentData = null;
let leads = [];
const $ = id => document.getElementById(id);

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.remove('hidden');
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.add('hidden'), 2400);
}
function todayStr() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function normalizeCategory(value) {
  if (['工厂', '工厂/制造商', '外贸行业客户', '货代同行'].includes(value)) return value === '货代同行' ? '未分类' : '工厂';
  if (['采购商', '潜在采购商'].includes(value)) return '采购商';
  if (['出货需求', '出货客户'].includes(value)) return '出货需求';
  return '未分类';
}
function categoriesOf(record) {
  const raw = Array.isArray(record.categories) && record.categories.length ? record.categories[0] : (record.demandTag || '未分类');
  return [normalizeCategory(raw)];
}


async function loadLeads() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  leads = Array.isArray(stored[STORAGE_KEY]) ? stored[STORAGE_KEY] : [];
  updateBadge();
}
async function saveLeads() {
  await chrome.storage.local.set({ [STORAGE_KEY]: leads });
  updateBadge();
}
function updateBadge() { $('leadCount').textContent = String(leads.length); }
function findLeadByUrl(url) { return leads.find(item => item.url === url); }

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error('没有找到当前标签页');
  return tab;
}
async function extractCurrentPage() {
  const tab = await getCurrentTab();
  if (!/^https?:/i.test(tab.url || '')) throw new Error('浏览器内置页面不支持识别');
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_LEAD' });
    if (response?.ok && response.data) return response.data;
  } catch (_) {}
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => window.__fbExtractLead ? window.__fbExtractLead() : null
  });
  if (results?.[0]?.result) return results[0].result;
  throw new Error('当前网页未能识别，请确认它属于支持的平台并刷新页面');
}

function updateScanStatus(data) {
  const hasContact = Boolean(data.phone || data.whatsapp);
  const missing = [];
  if (!data.company) missing.push('客户 / 公司名称');
  if (!hasContact) missing.push('电话或 WhatsApp');
  if (missing.length) {
    $('scanStatus').textContent = `已扫描 ${data.source || '当前网页'}：还缺少 ${missing.join('、')}，暂不会自动保存为有效客户。可手动补充后保存。`;
  } else {
    $('scanStatus').textContent = `已识别 ${data.source || '当前网页'}：${data.company}。资料符合要求，已尝试自动保存到客户库。`;
  }
}
function fillForm(data) {
  $('fCompany').value = data.company || '';
  $('fCountry').value = data.country || '';
  $('fPhone').value = data.phone || '';
  $('fWhatsapp').value = data.whatsapp || '';
  $('fEmail').value = data.email || '';
  $('fWebsite').value = data.website || '';
  $('fSource').value = data.source || '';
  $('fUrl').value = data.url || '';
  $('fNote').value = data.note || '';
  const existing = findLeadByUrl(data.url);
  $('fCategory').value = existing ? categoriesOf(existing)[0] : categoriesOf(data)[0];

  $('dupWarning').classList.toggle('hidden', !existing);
  if (existing) {
    // 若新页面读取不到某字段，保留线索库中人工补全的值。
    ['country', 'phone', 'whatsapp', 'email', 'website', 'note'].forEach(key => {
      const fieldMap = { country: 'fCountry', phone: 'fPhone', whatsapp: 'fWhatsapp', email: 'fEmail', website: 'fWebsite', note: 'fNote' };
      if (!$(fieldMap[key]).value && existing[key]) $(fieldMap[key]).value = existing[key];
    });
  }
  updateScanStatus(data);
  $('extractBar').classList.add('hidden');
  $('captureForm').classList.remove('hidden');
}
function showExtractBar(message) {
  if (message) $('scanStatus').textContent = message;
  $('extractBar').classList.remove('hidden');
  $('captureForm').classList.add('hidden');
}
async function autoLoad() {
  try {
    const data = await extractCurrentPage();
    if (!data?.url) throw new Error('当前页面未返回有效资料');
    currentData = data;
    fillForm(data);
  } catch (error) {
    showExtractBar(error.message || '未能自动识别当前网页。请打开支持平台上的客户主页后重试。');
  }
}
async function handleExtract() {
  try {
    $('scanStatus').textContent = '正在重新识别当前页面…';
    const data = await extractCurrentPage();
    if (!data?.url) throw new Error('提取失败');
    currentData = data;
    fillForm(data);
    toast('识别完成，请核对资料');
  } catch (error) {
    toast(error.message || '当前页面不允许提取');
  }
}

// Tabs
Array.from(document.querySelectorAll('.tab-btn')).forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(item => item.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(item => item.classList.remove('active'));
    button.classList.add('active');
    $('tab-' + button.dataset.tab).classList.add('active');
    if (button.dataset.tab === 'library') renderList();
    if (button.dataset.tab === 'capture') autoLoad();
  });
});
$('btnExtract').addEventListener('click', handleExtract);
$('btnReExtract').addEventListener('click', handleExtract);

// 保存客户：公司名必填，电话 / WhatsApp 至少一项。
$('captureForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!currentData?.url) return toast('请先识别当前网页');
  const record = {
    company: $('fCompany').value.trim(),
    country: $('fCountry').value.trim(),
    phone: $('fPhone').value.trim(),
    whatsapp: $('fWhatsapp').value.trim(),
    email: $('fEmail').value.trim(),
    website: $('fWebsite').value.trim(),
    source: $('fSource').value.trim() || currentData.source || '',
    url: $('fUrl').value.trim(),
    categories: [$('fCategory').value],
    demandTag: $('fCategory').value,
    note: $('fNote').value.trim()
  };
  if (!record.company) return toast('客户 / 公司名称为必填项');
  if (!record.phone && !record.whatsapp) return toast('电话或 WhatsApp 至少填写一项');
  if (!record.url) return toast('缺少客户主页链接，无法去重');

  const now = new Date().toISOString();
  const existing = findLeadByUrl(record.url);
  if (existing) {
    Object.assign(existing, record, { updatedAt: now });
    toast('已更新原客户记录');
  } else {
    leads.unshift({
      id: genId(), ...record,
      status: '待联系', contactedAt: '', reply: '', nextFollowUp: '',
      createdAt: todayStr(), updatedAt: now, autoCaptured: false
    });
    toast('客户已保存到本地客户库');
  }
  await saveLeads();
  currentData = { ...currentData, ...record };
  $('dupWarning').classList.toggle('hidden', !existing);
  renderList();
  updateScanStatus(currentData);
});

function renderList() {
  const keyword = $('searchInput').value.trim().toLowerCase();
  const category = $('categoryFilter').value;
  const filtered = leads.filter(lead => {
    const haystack = [lead.company, lead.country, lead.phone, lead.whatsapp, lead.email, lead.website,
      lead.note, lead.source, ...categoriesOf(lead)].join(' ').toLowerCase();
    const matchesKeyword = !keyword || haystack.includes(keyword);
    const matchesCategory = !category || categoriesOf(lead).includes(category);
    return matchesKeyword && matchesCategory;
  });
  $('emptyState').classList.toggle('hidden', filtered.length > 0);
  const container = $('leadList');
  container.innerHTML = '';
  filtered.forEach(lead => {
    const card = document.createElement('article');
    card.className = 'lead-card';
    const rows = [];
    if (lead.country) rows.push(`<div><b>国家/地区：</b>${escapeHtml(lead.country)}</div>`);
    if (lead.phone) rows.push(`<div><b>电话：</b>${escapeHtml(lead.phone)}</div>`);
    if (lead.whatsapp) rows.push(`<div><b>WhatsApp：</b>${escapeHtml(lead.whatsapp)}</div>`);
    if (lead.email) rows.push(`<div><b>邮箱：</b>${escapeHtml(lead.email)}</div>`);
    if (lead.website) rows.push(`<div><b>网站：</b>${escapeHtml(lead.website)}</div>`);
    rows.push(`<div><b>来源：</b>${escapeHtml(lead.source || '手动录入')}</div>`);
    const chips = categoriesOf(lead).map(category => `<span class="tag-pill">${escapeHtml(category)}</span>`).join('');
    card.innerHTML = `
      <div class="lead-card-head">
        <div><div class="lead-company">${escapeHtml(lead.company)}</div><div class="lead-source">${escapeHtml(lead.source || '手动录入')} · ${escapeHtml(lead.createdAt || '')}</div></div>
        <button class="btn btn-danger" data-act="delete">删除</button>
      </div>
      <div class="lead-meta">${rows.join('')}<div><b>主页：</b><a href="${escapeHtml(lead.url)}" target="_blank" rel="noopener">打开客户主页</a></div></div>
      <div class="lead-tags">${chips}<span class="tag-pill status">${escapeHtml(lead.status || '待联系')}</span></div>
      <label class="inline-category">客户分类：<select data-field="category">${CATEGORY_OPTIONS.map(c => `<option value="${c}" ${c === categoriesOf(lead)[0] ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
      <div class="card-actions"><button class="link-btn" data-act="toggle">跟进记录 ▾</button><span class="hint" style="margin:0">${lead.autoCaptured ? '自动识别' : '手动保存'}</span></div>
      <div class="lead-followup hidden">
        <label>跟进状态<select data-field="status">${STATUS_OPTIONS.map(s => `<option ${s === (lead.status || '待联系') ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
        <label>联系时间<input type="date" data-field="contactedAt" value="${escapeHtml(lead.contactedAt || '')}" /></label>
        <label>回复情况<input type="text" data-field="reply" value="${escapeHtml(lead.reply || '')}" placeholder="客户回复情况" /></label>
        <label>下次跟进日期<input type="date" data-field="nextFollowUp" value="${escapeHtml(lead.nextFollowUp || '')}" /></label>
      </div>`;

    card.querySelector('[data-act="delete"]').addEventListener('click', async () => {
      leads = leads.filter(item => item.id !== lead.id);
      await saveLeads();
      renderList();
      toast('客户记录已删除');
    });
    card.querySelector('[data-act="toggle"]').addEventListener('click', event => {
      const panel = card.querySelector('.lead-followup');
      panel.classList.toggle('hidden');
      event.currentTarget.textContent = panel.classList.contains('hidden') ? '跟进记录 ▾' : '跟进记录 ▴';
    });
    card.querySelectorAll('[data-field]').forEach(input => {
      input.addEventListener('change', async () => {
        if (input.dataset.field === 'category') {
          lead.categories = [input.value];
          lead.demandTag = input.value;
        } else {
          lead[input.dataset.field] = input.value;
        }
        lead.updatedAt = new Date().toISOString();
        await saveLeads();
        if (input.dataset.field === 'category') renderList();
        toast(input.dataset.field === 'category' ? '客户分类已更新' : '跟进信息已保存');
      });
    });
    container.appendChild(card);
  });
}
$('searchInput').addEventListener('input', renderList);
$('categoryFilter').addEventListener('change', renderList);

function csvCell(value) {
  const s = String(value ?? '');
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function exportCsv() {
  if (!leads.length) return toast('暂无线索可导出');
  const headers = ['客户/公司名称','国家/地区','电话','WhatsApp','邮箱','公司网站','来源平台','客户分类','客户主页','备注','跟进状态','联系时间','回复情况','下次跟进日期','采集日期'];
  const rows = [headers];
  leads.forEach(lead => rows.push([
    lead.company, lead.country, lead.phone, lead.whatsapp, lead.email, lead.website, lead.source,
    categoriesOf(lead).join(' / '), lead.url, lead.note, lead.status, lead.contactedAt,
    lead.reply, lead.nextFollowUp, lead.createdAt
  ].map(csvCell)));
  const blob = new Blob(['\ufeff' + rows.map(row => row.join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `huotongda_customer_leads_${todayStr()}.csv`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast('CSV 已导出，可用 Excel 打开');
}
$('btnExport').addEventListener('click', exportCsv);

// 货通达：直接由扩展侧边栏调用 chrome.tabs.create 创建平台标签页，
// 不再依赖 service worker 消息转发，避免后台监听未就绪时按钮无响应。
const PLATFORM_URLS = {
  linkedin: 'https://www.linkedin.com/',
  youtube: 'https://www.youtube.com/',
  facebook: 'https://www.facebook.com/',
  instagram: 'https://www.instagram.com/',
  tiktok: 'https://www.tiktok.com/',
  pinterest: 'https://www.pinterest.com/',
  x: 'https://x.com/'
};
const PLATFORM_KEYS = ['linkedin', 'youtube', 'facebook', 'instagram', 'tiktok', 'pinterest', 'x'];
const PLATFORM_NAMES = {
  linkedin: 'LinkedIn', youtube: 'YouTube', facebook: 'Facebook',
  instagram: 'Instagram', tiktok: 'TikTok', pinterest: 'Pinterest', x: 'X'
};
function createPlatformTab(url, active = true) {
  return new Promise((resolve, reject) => {
    if (!chrome?.tabs?.create) {
      reject(new Error('当前浏览器不支持扩展创建标签页，请使用桌面版 Chrome 或 Edge。'));
      return;
    }
    chrome.tabs.create({ url, active }, tab => {
      const err = chrome.runtime?.lastError;
      if (err) reject(new Error(err.message));
      else if (!tab || typeof tab.id !== 'number') reject(new Error('浏览器没有创建新标签页，请检查扩展权限。'));
      else resolve(tab);
    });
  });
}
async function openPlatform(key) {
  const url = PLATFORM_URLS[key];
  const name = PLATFORM_NAMES[key];
  if (!url) throw new Error('不支持的平台');
  await createPlatformTab(url, true);
  $('globalSearchStatus').textContent = `已打开 ${name}。请在该平台内搜索工厂、制造商或供应商；进入企业主页后，货通达可识别页面公开资料。`;
  toast(`${name} 已打开`);
}
async function launchGlobalSearch() {
  const btn = $('btnGlobalSearch');
  btn.disabled = true;
  $('globalSearchStatus').textContent = '正在创建七个平台标签页…';
  const opened = [];
  const failed = [];
  try {
    // 逐个创建，避免并发调用导致浏览器偶发拒绝；首个标签页置前台。
    for (const key of PLATFORM_KEYS) {
      try {
        await createPlatformTab(PLATFORM_URLS[key], opened.length === 0);
        opened.push(key);
      } catch (error) {
        failed.push(`${PLATFORM_NAMES[key]}（${error.message}）`);
      }
    }
    if (failed.length) {
      $('globalSearchStatus').textContent = `成功打开 ${opened.length}/7 个平台。${failed.length ? '失败：' + failed.join('；') : ''}`;
      toast(`已打开 ${opened.length}/7 个平台`);
    } else {
      $('globalSearchStatus').textContent = '七个平台已全部打开：LinkedIn、YouTube、Facebook、Instagram、TikTok、Pinterest、X。';
      toast('七个平台已全部打开');
    }
  } finally {
    btn.disabled = false;
  }
}
$('btnGlobalSearch').addEventListener('click', () => {
  launchGlobalSearch().catch(error => {
    $('globalSearchStatus').textContent = `打开失败：${error.message || '请检查浏览器扩展权限'}`;
    toast('打开平台失败');
  });
});
document.querySelectorAll('.platform-open').forEach(button => {
  button.addEventListener('click', () => openPlatform(button.dataset.platform).catch(error => {
    $('globalSearchStatus').textContent = `打开 ${PLATFORM_NAMES[button.dataset.platform] || '平台'} 失败：${error.message || '请检查浏览器扩展权限'}`;
    toast('打开平台失败');
  }));
});

loadLeads().then(autoLoad).catch(() => showExtractBar("本地客户库读取失败，请检查扩展存储权限。"));
