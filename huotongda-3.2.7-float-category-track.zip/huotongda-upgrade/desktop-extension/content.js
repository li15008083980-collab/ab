// 货通达：只读取当前页面公开可见的商务资料，不翻页、不批量访问、不绕过登录或权限。
(function () {
  const STORAGE_KEY = 'fb_leads';
  const GENERIC_NAMES = new Set([
    'facebook', 'instagram', 'linkedin', 'x', 'twitter', 'tiktok', 'thomasnet', 'importinfo',
    'home', 'homepage', 'log in', 'login', 'sign in', 'search', 'search results', 'news feed',
    '首页', '主页', '登录', '注册', '搜索', '搜索结果', '动态', '帖子'
  ]);
  const SOCIAL_HOSTS = [
    'facebook.com', 'fb.com', 'messenger.com', 'instagram.com', 'linkedin.com',
    'x.com', 'twitter.com', 'tiktok.com', 'youtube.com', 'pinterest.com', 'wa.me', 'whatsapp.com'
  ];

  function uniq(values) {
    return [...new Set(values.map(v => String(v || '').trim()).filter(Boolean))];
  }

  function cleanName(value) {
    return String(value || '')
      .replace(/^\s*(?:\|\s*)?/, '')
      .replace(/\s*[|·–—-]\s*(?:Facebook|Instagram|LinkedIn|X|Twitter|TikTok|Thomasnet).*$/i, '')
      .replace(/\s*[|·–—-]\s*(?:Home|Posts|About|Photos|Videos|Reviews|More|首页|帖子|关于|照片|视频|评价).*$/i, '')
      .replace(/\s*\(@[^)]*\)\s*$/, '')
      .trim();
  }

  function normalizeUrl(rawUrl) {
    try {
      const u = new URL(rawUrl);
      u.hash = '';
      ['utm_source', 'utm_medium', 'utm_campaign', 'ref', 'refsrc'].forEach(k => u.searchParams.delete(k));
      const host = u.hostname.toLowerCase().replace(/^www\./, '').replace(/^m\./, '').replace(/^web\./, '');
      if (host.endsWith('facebook.com') || host === 'fb.com') {
        if (u.pathname.includes('profile.php')) {
          const id = u.searchParams.get('id');
          return id ? 'https://www.facebook.com/profile.php?id=' + id : 'https://www.facebook.com' + u.pathname;
        }
        const first = u.pathname.split('/').filter(Boolean)[0];
        return first ? 'https://www.facebook.com/' + first : 'https://www.facebook.com/';
      }
      return u.origin + u.pathname.replace(/\/$/, '');
    } catch (_) {
      return rawUrl;
    }
  }

  function getJsonLd() {
    const found = [];
    document.querySelectorAll('script[type="application/ld+json"]').forEach(script => {
      try {
        const parsed = JSON.parse(script.textContent || 'null');
        const collect = value => {
          if (!value) return;
          if (Array.isArray(value)) return value.forEach(collect);
          if (typeof value !== 'object') return;
          found.push(value);
          if (value['@graph']) collect(value['@graph']);
          if (value.mainEntity) collect(value.mainEntity);
          if (value.itemListElement) collect(value.itemListElement);
        };
        collect(parsed);
      } catch (_) {}
    });
    return found;
  }

  function extractName(jsonLd) {
    const candidates = [];
    const h1 = document.querySelector('h1');
    if (h1?.innerText) candidates.push(h1.innerText);
    for (const selector of [
      'meta[property="og:site_name"]', 'meta[property="og:title"]',
      'meta[name="twitter:title"]', 'meta[name="title"]'
    ]) {
      const el = document.querySelector(selector);
      if (el?.content) candidates.push(el.content);
    }
    jsonLd.forEach(item => {
      if (typeof item.name === 'string') candidates.push(item.name);
      if (typeof item.alternateName === 'string') candidates.push(item.alternateName);
    });
    if (document.title) candidates.push(document.title);

    for (const candidate of candidates) {
      const name = cleanName(candidate);
      const normalized = name.toLowerCase();
      if (name.length >= 2 && name.length <= 120 && !GENERIC_NAMES.has(normalized) && !/^https?:/i.test(name)) {
        return name;
      }
    }
    return '';
  }

  function extractCountry(jsonLd, pageText) {
    for (const item of jsonLd) {
      const address = item.address;
      if (typeof address === 'string' && address.trim()) return address.trim();
      if (address && typeof address === 'object') {
        const parts = [address.addressLocality, address.addressRegion, address.addressCountry].filter(Boolean);
        if (parts.length) return parts.join(', ');
      }
      if (item.addressCountry) return String(item.addressCountry);
    }
    const match = pageText.match(/(?:所在地|地址|location|based in|based at)\s*[:：]?\s*([^\n|;]{2,80})/i);
    return match ? match[1].trim() : '';
  }

  function extractContacts(pageText) {
    const emails = uniq((pageText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [])
      .filter(value => !/\.(png|jpe?g|gif|webp|svg|css|js)$/i.test(value)));

    const wa = [];
    document.querySelectorAll('a[href*="wa.me"],a[href*="whatsapp.com"]').forEach(a => {
      const href = a.href || '';
      const direct = href.match(/wa\.me\/(\+?\d{7,15})/i);
      const query = href.match(/[?&]phone=(\+?\d{7,15})/i);
      if (direct) wa.push(direct[1]);
      if (query) wa.push(query[1]);
      const textMatch = (a.innerText || '').match(/(?:\+?\d[\d\s().-]{6,}\d)/);
      if (textMatch) wa.push(textMatch[0]);
    });
    const waText = /(?:whatsapp|wa\.me|wa)\s*[:：]?\s*((?:\+?\d[\d\s().-]{6,}\d))/gi;
    let m;
    while ((m = waText.exec(pageText)) !== null) wa.push(m[1]);
    const whatsapp = uniq(wa).map(v => v.replace(/[^\d+]/g, '')).filter(v => v.replace(/\D/g, '').length >= 7);

    const phoneMatches = pageText.match(/(?:\+|00)?\d[\d\s().-]{5,}\d/g) || [];
    const waDigits = new Set(whatsapp.map(v => v.replace(/\D/g, '')));
    const phones = uniq(phoneMatches.filter(value => {
      const digits = value.replace(/\D/g, '');
      if (digits.length < 7 || digits.length > 15) return false;
      if (/^\d{1,4}[/.\-]\d{1,2}[/.\-]\d{1,4}$/.test(value.trim())) return false;
      if (waDigits.has(digits)) return false;
      // 防止把一长串订单号当电话：必须含国际区号符号或分隔符。
      return /[+()\s.-]/.test(value);
    })).map(v => v.replace(/\s+/g, ' ').trim());

    return { phone: phones.slice(0, 3).join('; '), whatsapp: whatsapp.slice(0, 3).join('; '), email: emails.slice(0, 5).join('; ') };
  }

  function extractWebsite(jsonLd) {
    const blocked = SOCIAL_HOSTS.concat(['google.com', 'googleapis.com', 'gstatic.com', 'doubleclick.net', 'schema.org', 'w3.org']);
    const candidates = [];
    jsonLd.forEach(item => {
      if (typeof item.url === 'string') candidates.push(item.url);
      if (typeof item.sameAs === 'string') candidates.push(item.sameAs);
    });
    document.querySelectorAll('a[href^="http"]').forEach(a => {
      try {
        const u = new URL(a.href);
        if ((u.hostname === 'l.facebook.com' || u.hostname === 'lm.facebook.com') && u.searchParams.get('u')) {
          candidates.push(u.searchParams.get('u'));
        } else {
          candidates.push(u.origin + u.pathname.replace(/\/$/, ''));
        }
      } catch (_) {}
    });
    const websites = [];
    candidates.forEach(raw => {
      try {
        const u = new URL(raw);
        const host = u.hostname.toLowerCase().replace(/^www\./, '');
        if (!['http:', 'https:'].includes(u.protocol)) return;
        if (blocked.some(domain => host === domain || host.endsWith('.' + domain))) return;
        if (host.includes('google.') || host.includes('cdn.') || host.includes('font')) return;
        websites.push(u.origin + u.pathname.replace(/\/$/, ''));
      } catch (_) {}
    });
    return uniq(websites).slice(0, 3).join('; ');
  }

  function classify(text) {
    const t = (text || '').toLowerCase();
    const categories = [];
    const has = pattern => pattern.test(t);
    // 多语言工厂识别：优先捕捉明确制造/生产/加工身份，不把普通零售商自动判为工厂。
    const factorySignal = has(/\b(factory|factories|manufacturer|manufacturers|manufacturing|manufacturing company|manufacturing plant|production company|production plant|production facility|production workshop|industrial plant|industrial manufacturer|industrial company|producer|production line|processing plant|processing factory|fabricator|fabrication company|contract manufacturer|private label manufacturer|original equipment manufacturer|oem|odm|made in our factory|own factory|in-house production|mass production|wholesale manufacturer|assembly plant|machine shop|metalworking|metal fabrication|injection molding|die casting|cnc machining|textile mill|food processing plant|chemical plant)\b|工厂|工厂直销|工厂制造|制造商|制造厂家|生产厂家|生产商|生产企业|加工厂|代工厂|源头工厂|实力厂家|自有工厂|工业制造|生产基地|生产车间|生产线|批量生产|来料加工|贴牌生产|委托加工|工場|製造業|メーカー|生産工場|自社工場|製造元|제조업체|제조사|생산공장|공장직영|자체생산|제조공장|fábrica|fabricante|fabricantes|manufactura|planta de producción|empresa manufacturera|fabricación|productor|usine|fabricant|fabrication|entreprise industrielle|site de production|hersteller|fertigung|produktionsbetrieb|produktionsstätte|produktionsanlage|produzent|fabrik|fabbrica|produttore|produzione|azienda manifatturiera|stabilimento|fabriek|fabrikant|productiebedrijf|productie|производитель|производство|завод|фабрика|производственная компания|مصنع|شركة تصنيع|مصنع إنتاج|إنتاج صناعي|nhà máy|nhà sản xuất|xưởng sản xuất|sản xuất|pabrik|produsen|pabrik manufaktur|kilang|pengilang|kemudahan pengeluaran/);
    const factoryContext = has(/\b(we manufacture|we produce|our factory|our manufacturing|our production facility|factory direct|manufacturer direct|manufactured by us|in-house manufacturing|production capacity|manufacturing capacity|factory address|factory tour|made in our facility)\b|本厂生产|自主生产|自有生产线|厂家直供|工厂地址|生产能力|产能|厂房|车间|生产设备|生产流程|工厂实拍|生产实拍|工厂参观|自营工厂|メーカー直営|自社製造|自社生産|직접생산|자체공장|생산능력|fabricamos|fabricación propia|capacidad de producción|produit dans notre usine|notre usine|eigene produktion|produktionskapazität|produzione propria|capacità produttiva|собственное производство|производственные мощности|نصنع|قدرة إنتاجية|tự sản xuất|năng lực sản xuất|produksi sendiri|kapasitas produksi/);
    const factorySignalFinal = factorySignal || factoryContext;
    if (factorySignalFinal) {
      categories.push('外贸行业客户', '工厂/制造商');
    }
    if (has(/need (?:a )?(?:freight forwarder|shipping agent)|looking for (?:a )?(?:freight|shipping)|freight quote|shipping quote|need shipping|cargo shipment|ship from china|sea freight|air freight|fcl|lcl|ddp|fba shipping|货运询价|需要货代|出货|海运|空运/)) categories.push('出货需求');
    if (has(/importer|buyer|purchasing|procurement|sourcing manager|purchase department|进口商|采购商/)) categories.push('潜在采购商');
    if (!factorySignalFinal && has(/exporter|wholesale|supplier|shipper|brand owner|出口商|批发/)) categories.push('出货客户');
    if (!factorySignalFinal && has(/trading company|international trade|import.?export|export business|外贸公司|进出口贸易/)) categories.push('外贸行业客户');
    if (has(/freight forwarder|freight forwarding|logistics provider|shipping agent|nvocc|customs broker|freight brokerage|货运代理|国际货代|物流公司/)) categories.push('货代同行');
    return categories.length ? uniq(categories) : ['待核实'];
  }

  function getPlatform() {
    const host = location.hostname.toLowerCase();
    if (host.includes('facebook')) return 'Facebook';
    if (host.includes('instagram')) return 'Instagram';
    if (host.includes('linkedin')) return 'LinkedIn';
    if (host === 'x.com' || host.endsWith('.x.com') || host.includes('twitter')) return 'X';
    if (host.includes('tiktok')) return 'TikTok';
    if (host.includes('youtube')) return 'YouTube';
    if (host.includes('pinterest')) return 'Pinterest';
    if (host.includes('thomasnet')) return 'Thomasnet';
    if (host.includes('importinfo')) return 'ImportInfo';
    return host;
  }

  function isCandidatePage() {
    const host = location.hostname.toLowerCase();
    const path = location.pathname.toLowerCase();
    if (path === '/' || /^\/(search|explore|home|feed|foryou|watch|jobs|messaging|mynetwork)(\/|$)/.test(path)) return false;
    if (host.includes('instagram.com') && /^\/(p|reel|reels|stories|explore)(\/|$)/.test(path)) return false;
    if (host.includes('linkedin.com') && /^\/(feed|search|jobs|messaging|mynetwork)(\/|$)/.test(path)) return false;
    if ((host === 'x.com' || host.endsWith('.x.com') || host.includes('twitter.com')) && (/\/status\//.test(path) || /^\/(i|search|home)(\/|$)/.test(path))) return false;
    if (host.includes('tiktok.com') && (/^\/(search|tag|music|foryou)(\/|$)/.test(path) || /\/video\//.test(path))) return false;
    if (host.includes('youtube.com') && (/^\/(results|feed|shorts|watch)(\/|$)/.test(path) || !/^\/(?:channel\/|@|user\/|c\/)/.test(path))) return false;
    if (host.includes('pinterest.com') && (/^\/(search|ideas|today)(\/|$)/.test(path) || /\/pin\//.test(path))) return false;
    if (host.includes('facebook.com') && (/^\/(search|watch|reel|reels|marketplace)(\/|$)/.test(path) || /\/posts\//.test(path))) return false;
    return true;
  }

  function extractLead() {
    const pageText = (document.body?.innerText || '').slice(0, 120000);
    const jsonLd = getJsonLd();
    const contacts = extractContacts(pageText);
    const company = extractName(jsonLd);
    const country = extractCountry(jsonLd, pageText);
    const website = extractWebsite(jsonLd);
    const categories = classify([company, pageText].join('\n'));
    return {
      company,
      country,
      ...contacts,
      website,
      url: normalizeUrl(location.href),
      source: getPlatform(),
      categories,
      demandTag: categories[0] || '待核实',
      note: '',
      scannedAt: new Date().toISOString()
    };
  }

  window.__fbExtractLead = extractLead;

  if (window.__freightLeadScriptLoaded) return;
  window.__freightLeadScriptLoaded = true;

  let scanTimer = null;
  let lastUrl = location.href;
  let lastSignature = '';

  async function autoSave(data) {
    // 公司/客户名称必填，电话与 WhatsApp 至少提供一项；邮箱和网站不是硬性条件。
    if (!data.company || (!data.phone && !data.whatsapp)) return;
    if (!chrome?.storage?.local) return;
    try {
      const result = await chrome.storage.local.get(STORAGE_KEY);
      const leads = Array.isArray(result[STORAGE_KEY]) ? result[STORAGE_KEY] : [];
      const existing = leads.find(item => item.url === data.url);
      const now = new Date().toISOString();
      if (existing) {
        // 新扫描为空的字段不覆盖用户已补充的资料。
        ['company', 'country', 'phone', 'whatsapp', 'email', 'website', 'source', 'categories', 'demandTag'].forEach(key => {
          const value = data[key];
          if (Array.isArray(value) ? value.length : Boolean(value)) existing[key] = value;
        });
        existing.lastScannedAt = now;
        existing.updatedAt = now;
      } else {
        leads.unshift({
          id: 'auto-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          ...data,
          status: '待联系',
          contactedAt: '', reply: '', nextFollowUp: '',
          createdAt: now.slice(0, 10), updatedAt: now,
          autoCaptured: true
        });
      }
      await chrome.storage.local.set({ [STORAGE_KEY]: leads.slice(0, 5000) });
    } catch (_) {}
  }

  function runAuto() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(async () => {
      try {
        if (!isCandidatePage()) return; // 不把搜索结果、信息流或单条帖子误存成客户
        const data = extractLead();
        const signature = [data.url, data.company, data.phone, data.whatsapp, data.email].join('|');
        if (signature !== lastSignature) {
          lastSignature = signature;
          await autoSave(data);
        }
      } catch (_) {}
    }, 1800);
  }

  // SPA 路由监听：适配 Facebook、Instagram、LinkedIn、YouTube、Pinterest、X、TikTok 的站内跳转。
  const originalPush = history.pushState;
  const originalReplace = history.replaceState;
  history.pushState = function () { const result = originalPush.apply(this, arguments); runAuto(); return result; };
  history.replaceState = function () { const result = originalReplace.apply(this, arguments); runAuto(); return result; };
  window.addEventListener('popstate', runAuto);

  // 监听当前页面异步加载的公开资料，避免不停轮询。
  const observer = new MutationObserver(() => runAuto());
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  setTimeout(() => observer.disconnect(), 15000);

  runAuto();
  setTimeout(runAuto, 3500);
  setTimeout(runAuto, 8000);

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === 'GET_LEAD') {
      try { sendResponse({ ok: true, data: extractLead() }); }
      catch (_) { sendResponse({ ok: false, data: null }); }
      return true;
    }
  });
})();
