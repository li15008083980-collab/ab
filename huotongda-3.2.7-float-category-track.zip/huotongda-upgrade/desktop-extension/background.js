// 点击扩展图标，在当前浏览器窗口打开统一获客侧边栏。
chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
});
chrome.action.onClicked.addListener((tab) => {
  if (tab?.windowId != null && chrome.sidePanel?.open) {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {});
  }
});

const HUOTONGDA_PLATFORM_URLS = {
  linkedin: 'https://www.linkedin.com/',
  youtube: 'https://www.youtube.com/',
  facebook: 'https://www.facebook.com/',
  instagram: 'https://www.instagram.com/',
  tiktok: 'https://www.tiktok.com/',
  pinterest: 'https://www.pinterest.com/',
  x: 'https://x.com/'
};

function createPlatformTab(url, active) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url, active }, tab => {
      const error = chrome.runtime.lastError;
      if (error) reject(new Error(error.message));
      else if (!tab) reject(new Error('浏览器没有返回新标签页信息'));
      else resolve(tab);
    });
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'HUOTONGDA_OPEN_PLATFORM') {
    const key = message.platform;
    const url = HUOTONGDA_PLATFORM_URLS[key];
    if (!url) {
      sendResponse({ ok: false, error: '平台名称无效' });
      return false;
    }
    createPlatformTab(url, true)
      .then(tab => sendResponse({ ok: true, openedPlatforms: [key], tabId: tab.id }))
      .catch(error => sendResponse({ ok: false, error: error.message || '浏览器拒绝创建标签页' }));
    return true;
  }

  if (message?.type === 'HUOTONGDA_OPEN_ALL_PLATFORMS') {
    const requested = Array.isArray(message.platforms) ? message.platforms : Object.keys(HUOTONGDA_PLATFORM_URLS);
    const keys = [...new Set(requested)].filter(key => Object.prototype.hasOwnProperty.call(HUOTONGDA_PLATFORM_URLS, key));
    if (!keys.length) {
      sendResponse({ ok: false, error: '没有可打开的平台' });
      return false;
    }
    (async () => {
      const openedPlatforms = [];
      const failedPlatforms = [];
      let firstTabActivated = false;
      for (const key of keys) {
        try {
          // 首个成功创建的平台切到前台，其余平台以后台标签页打开。
          await createPlatformTab(HUOTONGDA_PLATFORM_URLS[key], !firstTabActivated);
          openedPlatforms.push(key);
          firstTabActivated = true;
        } catch (error) {
          failedPlatforms.push(key);
        }
      }
      sendResponse({
        ok: openedPlatforms.length > 0,
        openedPlatforms,
        failedPlatforms,
        error: failedPlatforms.length ? '部分标签页未能创建，请确认浏览器允许扩展打开标签页。' : ''
      });
    })().catch(error => sendResponse({ ok: false, error: error.message || '批量打开失败' }));
    return true;
  }
  return false;
});

