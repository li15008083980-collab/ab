# 如何生成货通达 APK 安装包

当前云端对话环境内存约 1.2GB，无法完成 Android Gradle 编译。请用下面任一方式在本地或 GitHub 生成 APK。

## 方式一：Android Studio（推荐）

1. 安装 [Android Studio](https://developer.android.com/studio)
2. Open → 选择本包中的 `mobile-app` 目录
3. 等待 Gradle Sync 完成
4. 菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. 完成后点 **locate**，得到 `app-debug.apk`
6. 传到手机安装（需允许「安装未知应用」）

## 方式二：GitHub Actions 云端编译

1. 新建 GitHub 仓库，把整个 `huotongda-upgrade` 上传进去
2. 打开仓库 **Actions** → 选择 **Build HuoTongDa Android APK** → **Run workflow**
3. 成功后在 Artifacts 下载 `huotongda-3.2.6-debug-apk`，解压即得 APK

## 安装后使用

1. 打开「货通达」，点「开启悬浮球」
2. 授予「显示在其他应用上层」权限
3. **先在工作台添加/导入一次客户**（数据会同步给悬浮窗）
4. 之后在任意界面点悬浮球，即可直接搜索客户、拨打、复制、打开 WhatsApp
