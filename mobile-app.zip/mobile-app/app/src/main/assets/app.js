const PLATFORMS = [
  ['LinkedIn', 'https://www.linkedin.com/', 'linkedin://'],
  ['YouTube', 'https://www.youtube.com/', 'youtube://'],
  ['Facebook', 'https://www.facebook.com/', 'fb://'],
  ['Instagram', 'https://www.instagram.com/', 'instagram://'],
  ['TikTok', 'https://www.tiktok.com/', 'snssdk1233://'],
  ['Pinterest', 'https://www.pinterest.com/', 'pinterest://'],
  ['X', 'https://x.com/', 'twitter://']
];
const KEY = 'huotongda_mobile_leads_v1';
const CATEGORY_OPTIONS = ['工厂', '外贸采购', '出货需求', '未分类'];
const STATUS_OPTIONS = ['待联系', '已联系', '已回复', '已报价', '成交', '无效'];
let leads = JSON.parse(localStorage.getItem(KEY) || '[]');
const $ = id => document.getElementById(id);

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function normalizeCategory(value) {
  if (['工厂', '工厂/制造商', '外贸行业客户'].includes(value)) return '工厂';
  if (['外贸采购', '采购商', '潜在采购商'].includes(value)) return '外贸采购';
  if (['出货需求', '出货需要', '出货客户'].includes(value)) return '出货需求';
  return '未分类';
}
function categoryOf(record) {
  if (Array.isArray(record.categories) && record.categories.length) return normalizeCategory(record.categories[0]);
  if (record.demandTag) return normalizeCategory(record.demandTag);
  if (record.category) return normalizeCategory(record.category);
  return '未分类';
}
function normalizeLead(raw) {
  const cat = categoryOf(raw);
  return {
    id: raw.id || genId(),
    company: raw.company || '',
    country: raw.country || '',
    phone: raw.phone || '',
    whatsapp: raw.whatsapp || '',
    email: raw.email || '',
    url: raw.url || raw.website || '',
    website: raw.website || raw.url || '',
    source: raw.source || '手动录入',
    category: cat,
    categories: [cat],
    demandTag: cat,
    note: raw.note || '',
    status: STATUS_OPTIONS.includes(raw.status) ? raw.status : '待联系',
    contactedAt: raw.contactedAt || '',
    reply: raw.reply || '',
    nextFollowUp: raw.nextFollowUp || '',
    createdAt: raw.createdAt || new Date().toISOString().slice(0, 10),
    updatedAt: raw.updatedAt || new Date().toISOString()
  };
}
function migrateLeads() {
  leads = (Array.isArray(leads) ? leads : []).map(normalizeLead);
}

function syncNative() {
  try {
    if (window.HuoTongDa && window.HuoTongDa.syncLeads) window.HuoTongDa.syncLeads(JSON.stringify(leads));
  } catch (e) {}
}
function pullNative() {
  try {
    if (!(window.HuoTongDa && window.HuoTongDa.getLeads)) return;
    const native = JSON.parse(window.HuoTongDa.getLeads() || '[]');
    if (Array.isArray(native) && native.length) {
      leads = native.map(normalizeLead);
      localStorage.setItem(KEY, JSON.stringify(leads));
    } else if (leads.length) syncNative();
  } catch (e) {}
}
const save = () => {
  localStorage.setItem(KEY, JSON.stringify(leads));
  syncNative();
  render();
};

function openPlatform(item) {
  const [name, url, scheme] = item;
  if (window.HuoTongDa && window.HuoTongDa.openPlatform) {
    window.HuoTongDa.openPlatform(scheme || url, url);
    return;
  }
  if (scheme) {
    const a = document.createElement('a');
    a.href = scheme;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => window.open(url, '_blank', 'noopener'), 700);
  } else window.open(url, '_blank', 'noopener');
}

$('platforms').innerHTML = PLATFORMS.map((p, i) => `<button class="platform" data-i="${i}">${p[0]}</button>`).join('');
document.querySelectorAll('.platform').forEach(b => b.onclick = () => openPlatform(PLATFORMS[+b.dataset.i]));
$('openAll').onclick = () => { PLATFORMS.forEach((p, i) => setTimeout(() => openPlatform(p), i * 350)); };

$('addToggle').onclick = () => $('leadForm').classList.toggle('hidden');
$('leadForm').onsubmit = e => {
  e.preventDefault();
  const cat = normalizeCategory($('category').value);
  const item = normalizeLead({
    id: genId(),
    company: $('company').value.trim(),
    category: cat,
    categories: [cat],
    demandTag: cat,
    country: $('country').value.trim(),
    phone: $('phone').value.trim(),
    whatsapp: $('whatsapp').value.trim(),
    email: $('email').value.trim(),
    url: $('url').value.trim(),
    website: $('url').value.trim(),
    note: $('note').value.trim(),
    status: '待联系',
    createdAt: new Date().toISOString().slice(0, 10)
  });
  if (!item.company) return alert('请填写公司名称');
  if (!item.phone && !item.whatsapp) return alert('电话或 WhatsApp 至少填写一项');
  leads.unshift(item);
  save();
  e.target.reset();
  e.target.classList.add('hidden');
};

function render() {
  migrateLeads();
  $('total').textContent = leads.length;
  $('factoryCount').textContent = leads.filter(x => categoryOf(x) === '工厂').length;
  $('buyerCount').textContent = leads.filter(x => categoryOf(x) === '外贸采购').length;
  $('demandCount').textContent = leads.filter(x => categoryOf(x) === '出货需求').length;

  const q = $('search').value.toLowerCase();
  const f = $('filter').value;
  const sf = $('statusFilter').value;
  const rows = leads.filter(x => {
    const cat = categoryOf(x);
    const st = x.status || '待联系';
    if (f && cat !== f) return false;
    if (sf && st !== sf) return false;
    if (!q) return true;
    const hay = [x.company, x.country, x.phone, x.whatsapp, x.email, x.url, x.note, cat, st, x.reply, x.source]
      .join(' ').toLowerCase();
    return hay.includes(q);
  });

  $('leadList').innerHTML = rows.map(x => {
    const cat = categoryOf(x);
    const st = x.status || '待联系';
    return `<article class="lead-card" data-id="${esc(String(x.id))}">
      <div class="lead-title">${esc(x.company)}</div>
      <div class="pill-row">
        <span class="pill">${esc(cat)}</span>
        <span class="pill status">${esc(st)}</span>
      </div>
      <div class="lead-meta">${esc(x.country || '')} ${esc(x.phone || '')} ${esc(x.whatsapp || '')}<br>${esc(x.email || '')}<br>${x.url ? `<a href="${esc(x.url)}" target="_blank" rel="noopener">打开主页</a><br>` : ''}${esc(x.note || '')}</div>
      <label class="inline-field">客户分类
        <select data-field="category">${CATEGORY_OPTIONS.map(c => `<option value="${c}" ${c === cat ? 'selected' : ''}>${c}</option>`).join('')}</select>
      </label>
      <button type="button" class="link-btn" data-act="toggle">跟进记录 ▾</button>
      <div class="lead-followup hidden">
        <label>跟进状态
          <select data-field="status">${STATUS_OPTIONS.map(s => `<option value="${s}" ${s === st ? 'selected' : ''}>${s}</option>`).join('')}</select>
        </label>
        <label>联系时间<input type="date" data-field="contactedAt" value="${esc(x.contactedAt || '')}"></label>
        <label>回复情况<input type="text" data-field="reply" value="${esc(x.reply || '')}" placeholder="客户回复情况"></label>
        <label>下次跟进日期<input type="date" data-field="nextFollowUp" value="${esc(x.nextFollowUp || '')}"></label>
      </div>
      <button data-del="${esc(String(x.id))}" class="del-btn">删除</button>
    </article>`;
  }).join('') || '<p class="tip">暂无客户。可在工作台添加，也可直接在悬浮球面板添加与检索。</p>';

  document.querySelectorAll('[data-del]').forEach(b => {
    b.onclick = () => {
      leads = leads.filter(x => String(x.id) !== b.dataset.del);
      save();
    };
  });
  document.querySelectorAll('.lead-card').forEach(card => {
    const id = card.dataset.id;
    const lead = leads.find(x => String(x.id) === id);
    if (!lead) return;
    card.querySelector('[data-act="toggle"]')?.addEventListener('click', ev => {
      const panel = card.querySelector('.lead-followup');
      panel.classList.toggle('hidden');
      ev.currentTarget.textContent = panel.classList.contains('hidden') ? '跟进记录 ▾' : '跟进记录 ▴';
    });
    card.querySelectorAll('[data-field]').forEach(input => {
      input.addEventListener('change', () => {
        if (input.dataset.field === 'category') {
          const cat = normalizeCategory(input.value);
          lead.category = cat;
          lead.categories = [cat];
          lead.demandTag = cat;
        } else {
          lead[input.dataset.field] = input.value;
        }
        lead.updatedAt = new Date().toISOString();
        save();
      });
    });
  });
}

$('search').oninput = render;
$('filter').onchange = render;
$('statusFilter').onchange = render;
$('export').onclick = () => {
  const blob = new Blob([JSON.stringify(leads, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = '货通达客户备份.json';
  a.click();
  URL.revokeObjectURL(a.href);
};
$('importFile').onchange = async e => {
  try {
    const data = JSON.parse(await e.target.files[0].text());
    if (!Array.isArray(data)) throw Error();
    leads = data.map(normalizeLead);
    save();
    alert('导入完成');
  } catch (_) {
    alert('文件格式不正确');
  }
};

migrateLeads();
pullNative();
render();
