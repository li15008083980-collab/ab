package com.huotongda.app

import android.content.Context
import android.content.Intent

object LeadsStore {
    const val PREFS = "huotongda_leads"
    const val KEY = "json"
    const val ACTION_CHANGED = "com.huotongda.app.LEADS_CHANGED"

    fun save(context: Context, json: String) {
        val safe = if (json.isBlank()) "[]" else json
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, safe)
            .apply()
        context.sendBroadcast(Intent(ACTION_CHANGED).setPackage(context.packageName))
    }

    fun load(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
    }
}
