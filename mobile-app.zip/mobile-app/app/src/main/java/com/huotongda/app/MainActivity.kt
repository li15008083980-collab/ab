package com.huotongda.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(12, 8, 12, 8) }
        val title = TextView(this).apply { text = "货通达"; textSize = 20f; setPadding(4, 8, 12, 8) }
        val floatButton = Button(this).apply { text = "开启悬浮球"; setOnClickListener { enableFloating() } }
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(floatButton)
        root.addView(bar)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            addJavascriptInterface(PlatformBridge(this@MainActivity), "HuoTongDa")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    if (url.startsWith("file:///android_asset/")) return false
                    return try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); true } catch (_: Exception) { false }
                }
            }
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun enableFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }
}


class PlatformBridge(private val activity: Activity) {
    @JavascriptInterface
    fun openPlatform(scheme: String, fallbackUrl: String) {
        activity.runOnUiThread {
            try {
                val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(scheme))
                activity.startActivity(appIntent)
            } catch (_: Exception) {
                try { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl))) } catch (_: Exception) {}
            }
        }
    }

    @JavascriptInterface
    fun syncLeads(json: String) {
        LeadsStore.save(activity.applicationContext, json)
    }

    @JavascriptInterface
    fun getLeads(): String = LeadsStore.load(activity.applicationContext)
}
