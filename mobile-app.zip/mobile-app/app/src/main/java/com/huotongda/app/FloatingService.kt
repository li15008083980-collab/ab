package com.huotongda.app

import android.app.*
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Overlay panel aligned with desktop extension: search, category, tracking, quick add. */
class FloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: View? = null
    private var panel: View? = null
    private var resultBox: LinearLayout? = null
    private var statusView: TextView? = null
    private var addForm: LinearLayout? = null
    private var query: String = ""
    private var categoryFilter: String = ""
    private var statusFilter: String = ""
    private val channelId = "huotongda_floating"
    private val prefs by lazy { getSharedPreferences("floating_position", Context.MODE_PRIVATE) }

    private val categories = listOf("工厂", "外贸采购", "出货需求", "未分类")
    private val statuses = listOf("待联系", "已联系", "已回复", "已报价", "成交", "无效")

    private val leadsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (panel != null) renderResults()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            .setContentTitle("货通达悬浮球已开启")
            .setContentText("点击可检索客户、分类筛选与跟进")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
        else Notification.Builder(this).setContentTitle("货通达悬浮球已开启")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
        startForeground(325, notification)
        val filter = IntentFilter(LeadsStore.ACTION_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(leadsReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("UnspecifiedRegisterReceiverFlag") registerReceiver(leadsReceiver, filter)
        showBubble()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(channelId, "货通达悬浮球", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun bubbleBackground(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.rgb(25, 105, 190))
        setStroke(dp(2), Color.WHITE)
    }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "货\n通达"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = bubbleBackground()
            elevation = dp(8).toFloat()
            contentDescription = "货通达悬浮球，点击检索客户"
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(58), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = prefs.getInt("x", dp(12)); y = prefs.getInt("y", dp(240))
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX; val dy = event.rawY - downY
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) moved = true
                    if (moved) {
                        params.x = (startX - dx.toInt()).coerceAtLeast(0)
                        params.y = (startY + dy.toInt()).coerceAtLeast(0)
                        windowManager?.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
                    else togglePanel()
                    true
                }
                else -> true
            }
        }
        bubble = view
        windowManager?.addView(view, params)
    }

    private fun fieldBg() = GradientDrawable().apply {
        setColor(Color.rgb(245, 248, 252)); cornerRadius = dp(10).toFloat()
    }

    private fun togglePanel() {
        if (panel != null) { removePanel(); return }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(220, 228, 238))
            }
            elevation = dp(12).toFloat()
        }
        card.addView(TextView(this).apply {
            text = "客户检索 · 分类 · 跟进"
            textSize = 16f
            setTextColor(Color.rgb(28, 48, 72))
        })
        statusView = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(2), 0, dp(6))
        }
        card.addView(statusView)

        val input = EditText(this).apply {
            hint = "公司 / 国家 / 电话 / WhatsApp / 分类 / 状态"
            textSize = 13f
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = fieldBg()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    query = s?.toString().orEmpty()
                    renderResults()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        card.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(6)
        })

        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val catSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@FloatingService, android.R.layout.simple_spinner_dropdown_item,
                listOf("全部分类") + categories)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    categoryFilter = if (position == 0) "" else categories[position - 1]
                    renderResults()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        val stSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@FloatingService, android.R.layout.simple_spinner_dropdown_item,
                listOf("全部状态") + statuses)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    statusFilter = if (position == 0) "" else statuses[position - 1]
                    renderResults()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        filterRow.addView(catSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        filterRow.addView(stSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(6)
        })
        card.addView(filterRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(6)
        })

        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(resultBox) }
        card.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)))

        addForm = buildAddForm()
        addForm?.visibility = View.GONE
        card.addView(addForm)

        card.addView(actionButton("＋ 在悬浮窗添加客户") {
            addForm?.visibility = if (addForm?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        card.addView(actionButton("打开完整工作台") { openWorkspace() })
        card.addView(actionButton("收起") { removePanel() })
        card.addView(actionButton("关闭悬浮球") { stopSelf() })

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(320), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(6); y = dp(60)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        panel = card
        windowManager?.addView(card, params)
        renderResults()
    }

    private fun buildAddForm(): LinearLayout {
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.rgb(247, 249, 253)); cornerRadius = dp(10).toFloat()
            }
        }
        form.addView(TextView(this).apply {
            text = "快速添加（与电脑端分类一致）"
            textSize = 13f
            setTextColor(Color.rgb(28, 48, 72))
            setPadding(0, 0, 0, dp(6))
        })
        val company = EditText(this).apply { hint = "公司 / 客户名称 *"; setSingleLine(true); background = fieldBg(); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val country = EditText(this).apply { hint = "国家 / 地区"; setSingleLine(true); background = fieldBg(); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val phone = EditText(this).apply { hint = "电话"; inputType = InputType.TYPE_CLASS_PHONE; setSingleLine(true); background = fieldBg(); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val whatsapp = EditText(this).apply { hint = "WhatsApp"; inputType = InputType.TYPE_CLASS_PHONE; setSingleLine(true); background = fieldBg(); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val email = EditText(this).apply { hint = "邮箱"; inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; setSingleLine(true); background = fieldBg(); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val note = EditText(this).apply { hint = "货运需求 / 备注"; setSingleLine(true); background = fieldBg(); setPadding(dp(8), dp(6), dp(8), dp(6)) }
        val cat = Spinner(this).apply {
            adapter = ArrayAdapter(this@FloatingService, android.R.layout.simple_spinner_dropdown_item, categories)
        }
        listOf(company, country, phone, whatsapp, email, note).forEach {
            form.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(5)
            })
        }
        form.addView(TextView(this).apply { text = "客户分类"; textSize = 11f; setTextColor(Color.GRAY) })
        form.addView(cat)
        form.addView(actionButton("保存到本机客户库") {
            val c = company.text.toString().trim()
            val p = phone.text.toString().trim()
            val w = whatsapp.text.toString().trim()
            if (c.isEmpty()) {
                statusView?.text = "请填写公司名称"
                return@actionButton
            }
            if (p.isEmpty() && w.isEmpty()) {
                statusView?.text = "电话或 WhatsApp 至少填写一项"
                return@actionButton
            }
            val catName = categories.getOrElse(cat.selectedItemPosition) { "未分类" }
            val arr = JSONArray(LeadsStore.load(this))
            val obj = JSONObject()
            val id = System.currentTimeMillis().toString(36)
            obj.put("id", id)
            obj.put("company", c)
            obj.put("country", country.text.toString().trim())
            obj.put("phone", p)
            obj.put("whatsapp", w)
            obj.put("email", email.text.toString().trim())
            obj.put("note", note.text.toString().trim())
            obj.put("category", catName)
            obj.put("categories", JSONArray().put(catName))
            obj.put("demandTag", catName)
            obj.put("status", "待联系")
            obj.put("contactedAt", "")
            obj.put("reply", "")
            obj.put("nextFollowUp", "")
            obj.put("source", "悬浮窗录入")
            obj.put("createdAt", java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()))
            obj.put("updatedAt", java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).format(java.util.Date()))
            // prepend
            val next = JSONArray()
            next.put(obj)
            for (i in 0 until arr.length()) next.put(arr.getJSONObject(i))
            LeadsStore.save(this, next.toString())
            company.setText(""); country.setText(""); phone.setText(""); whatsapp.setText(""); email.setText(""); note.setText("")
            addForm?.visibility = View.GONE
            statusView?.text = "已保存：$c"
            renderResults()
        })
        return form
    }

    private fun categoryOf(lead: JSONObject): String {
        val raw = when {
            lead.has("categories") && lead.optJSONArray("categories")?.length() ?: 0 > 0 ->
                lead.getJSONArray("categories").optString(0)
            lead.has("demandTag") -> lead.optString("demandTag")
            else -> lead.optString("category")
        }
        return when (raw) {
            "工厂", "工厂/制造商", "外贸行业客户" -> "工厂"
            "外贸采购", "采购商", "潜在采购商" -> "外贸采购"
            "出货需求", "出货需要", "出货客户" -> "出货需求"
            else -> "未分类"
        }
    }

    private fun loadLeads(): List<JSONObject> {
        return try {
            val arr = JSONArray(LeadsStore.load(this))
            List(arr.length()) { arr.getJSONObject(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun persistAll(list: List<JSONObject>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        LeadsStore.save(this, arr.toString())
    }

    private fun renderResults() {
        val box = resultBox ?: return
        box.removeAllViews()
        val all = loadLeads()
        val q = query.trim().lowercase()
        val rows = all.filter { lead ->
            val cat = categoryOf(lead)
            val st = lead.optString("status").ifBlank { "待联系" }
            if (categoryFilter.isNotEmpty() && cat != categoryFilter) return@filter false
            if (statusFilter.isNotEmpty() && st != statusFilter) return@filter false
            if (q.isEmpty()) return@filter true
            val hay = listOf(
                lead.optString("company"), cat, st,
                lead.optString("country"), lead.optString("phone"), lead.optString("whatsapp"),
                lead.optString("email"), lead.optString("url"), lead.optString("note"),
                lead.optString("reply"), lead.optString("source")
            ).joinToString(" ").lowercase()
            hay.contains(q)
        }
        statusView?.text = when {
            all.isEmpty() -> "本机暂无客户。可在下方直接添加，或从电脑端导入备份。"
            else -> "共 ${all.size} 条 · 匹配 ${rows.size} 条 · 关键词实时检索"
        }
        if (rows.isEmpty()) {
            box.addView(TextView(this).apply {
                text = if (all.isEmpty()) "暂无客户资料" else "没有匹配结果，试试换关键词或分类"
                setTextColor(Color.GRAY)
                textSize = 12f
                setPadding(0, dp(8), 0, dp(8))
            })
            return
        }
        rows.take(50).forEach { lead -> box.addView(leadCard(lead, all)) }
    }

    private fun leadCard(lead: JSONObject, all: List<JSONObject>): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = GradientDrawable().apply {
                setColor(Color.rgb(248, 250, 253)); cornerRadius = dp(10).toFloat()
            }
        }
        val company = lead.optString("company").ifBlank { "未命名客户" }
        val cat = categoryOf(lead)
        val st = lead.optString("status").ifBlank { "待联系" }
        wrap.addView(TextView(this).apply {
            text = company
            textSize = 14f
            setTextColor(Color.rgb(28, 48, 72))
        })
        wrap.addView(TextView(this).apply {
            text = "$cat · $st"
            textSize = 11f
            setTextColor(Color.rgb(45, 90, 150))
            setPadding(0, dp(2), 0, dp(2))
        })
        val meta = listOf(lead.optString("country"), lead.optString("phone"), lead.optString("whatsapp"))
            .filter { it.isNotBlank() }.joinToString(" · ")
        if (meta.isNotBlank()) wrap.addView(TextView(this).apply {
            text = meta; textSize = 11f; setTextColor(Color.DKGRAY)
        })
        val note = lead.optString("note")
        if (note.isNotBlank()) wrap.addView(TextView(this).apply {
            text = note; textSize = 11f; setTextColor(Color.GRAY); maxLines = 2
        })
        val follow = listOf(
            lead.optString("contactedAt").takeIf { it.isNotBlank() }?.let { "联系:$it" },
            lead.optString("nextFollowUp").takeIf { it.isNotBlank() }?.let { "下次:$it" },
            lead.optString("reply").takeIf { it.isNotBlank() }?.let { "回复:$it" }
        ).filterNotNull().joinToString(" · ")
        if (follow.isNotBlank()) wrap.addView(TextView(this).apply {
            text = follow; textSize = 10f; setTextColor(Color.rgb(80, 100, 80))
        })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val phone = lead.optString("phone").ifBlank { lead.optString("whatsapp") }
        if (phone.isNotBlank()) {
            actions.addView(miniButton("拨打") { dial(phone) })
            actions.addView(miniButton("复制") { copy(phone) })
        }
        val wa = lead.optString("whatsapp").filter { it.isDigit() }
        if (wa.isNotBlank()) actions.addView(miniButton("WhatsApp") { openUrl("https://wa.me/$wa") })
        if (actions.childCount > 0) wrap.addView(actions)

        // category + status quick update
        val editRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val catSp = Spinner(this).apply {
            adapter = ArrayAdapter(this@FloatingService, android.R.layout.simple_spinner_dropdown_item, categories)
            setSelection(categories.indexOf(cat).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                private var ready = false
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (!ready) { ready = true; return }
                    val next = categories[position]
                    lead.put("category", next)
                    lead.put("categories", JSONArray().put(next))
                    lead.put("demandTag", next)
                    lead.put("updatedAt", java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).format(java.util.Date()))
                    persistAll(all.map { if (it.optString("id") == lead.optString("id")) lead else it })
                    statusView?.text = "分类已更新为 $next"
                    renderResults()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        val stSp = Spinner(this).apply {
            adapter = ArrayAdapter(this@FloatingService, android.R.layout.simple_spinner_dropdown_item, statuses)
            setSelection(statuses.indexOf(st).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                private var ready = false
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (!ready) { ready = true; return }
                    val next = statuses[position]
                    lead.put("status", next)
                    lead.put("updatedAt", java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).format(java.util.Date()))
                    persistAll(all.map { if (it.optString("id") == lead.optString("id")) lead else it })
                    statusView?.text = "跟进状态：$next"
                    renderResults()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        editRow.addView(TextView(this).apply { text = "改分类 / 跟进状态"; textSize = 10f; setTextColor(Color.GRAY) })
        val spRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        spRow.addView(catSp, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        spRow.addView(stSp, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
        editRow.addView(spRow)
        wrap.addView(editRow)

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(8)
        wrap.layoutParams = lp
        return wrap
    }

    private fun miniButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 11f
        minimumHeight = 0
        minHeight = 0
        setPadding(dp(6), dp(2), dp(6), dp(2))
        setOnClickListener { action() }
    }

    private fun dial(phone: String) {
        openUrl("tel:${phone.filter { it.isDigit() || it == '+' }}")
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("lead", text))
        statusView?.text = "已复制 $text"
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun openWorkspace() {
        removePanel()
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    private fun removePanel() {
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        panel = null
        resultBox = null
        statusView = null
        addForm = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { unregisterReceiver(leadsReceiver) } catch (_: Exception) {}
        removePanel()
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
