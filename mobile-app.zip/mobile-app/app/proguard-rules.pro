# Keep WebView JavaScript interface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep FloatingService
-keep class com.huotongda.app.FloatingService { *; }
-keep class com.huotongda.app.MainActivity { *; }
-keep class com.huotongda.app.PlatformBridge { *; }
